package com.niit.shoppingcartbackendproject.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcartbackendproject.dao.UsersDAO;
import com.niit.shoppingcartbackendproject.model.Users;

public class UserTest {
	
	
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.niit.shoppingcartbackendproject");
		context.refresh();
		
		
	   UsersDAO usersDAO = 	(UsersDAO) context.getBean("usersDAO");
	   
	   Users users = 	(Users) context.getBean("users");
	   users.setId("users-1");
	   users.setName("Archana");
	   users.setAddress("RAJAJINAGAR");
	   users.setPassword("archana");
	   users.setMobile("9998887776");
	   users.setMail("abc@gmail.com");
	   users.setAdmin(true);
	   usersDAO.saveOrUpdate(users);
	   
	   users.setId("users-2");
	   users.setName("Nagashree");
	   users.setAddress("RAJAJINAGAR");
	   users.setPassword("nagashree");
	   users.setMobile("9998887777");
	   users.setMail("xyz@gmail.com");
	   users.setAdmin(false);
	   usersDAO.saveOrUpdate(users);
	   
	   
	   
	   
	  if(   usersDAO.get("users-1") ==null)
	  {
		  System.out.println("User does not exist");
	  }
	  else
	  {
		  System.out.println("User exist .. the details are ..");
		  System.out.println();
	  }
		
		
		
	}

}



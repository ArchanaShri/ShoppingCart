package com.niit.shoppingcartbackendproject.test;
/*package com.niit.shoppingcartbackendproject.test;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcartbackendproject.dao.SupplierDAO;
import com.niit.shoppingcartbackendproject.model.Supplier;

public class TestSupplierDAO {

	static SupplierDAO supplierDAO;
	static Supplier supplier;
	static AnnotationConfigApplicationContext context;
	@BeforeClass
	public static void init()
	{
		context=new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		supplierDAO=(SupplierDAO) context.getBean("supplierDAO");
		supplier=(Supplier) context.getBean("supplier");
	}

	@AfterClass
	public static void close()
	{
		context.close();
		supplierDAO=null;
		supplier=null;
	}
	@Test
	public void supplierTestCase() {
     int size=supplierDAO.list().size();
     assertEquals("Supplier list test case",5,size);
	
	}
	@Test
	public void userNameTestCase()
	{
		supplier=supplierDAO.get("Sup-1");
		String name=supplier.getName();
		assertEquals("Name Teest Case","Raj", name);
	}


}*/

package com.niit.shoppingcartbackendproject.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcartbackendproject.dao.ItemsDAO;
import com.niit.shoppingcartbackendproject.model.Items;

public class ItemsTest {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();

		context.scan("com.niit.shoppingcartbackendproject");
		context.refresh();

		ItemsDAO itemsDAO = (ItemsDAO) context.getBean("itemsDAO");

		Items items = (Items) context.getBean("items");
		items.setId("Itm-1");
		items.setName("Nokia");
		items.setDescription("Communicating India");
		items.setPrice(5500.60);
	
		itemsDAO.saveOrUpdate(items);

		
		items.setId("Itm-2");
		items.setName("Nokia");
		items.setDescription("Communicating India");
		items.setPrice(5500.60);
	
		itemsDAO.saveOrUpdate(items);

		
		items.setId("Itm-3");
		items.setName("Nokia");
		items.setDescription("Communicating India");
		items.setPrice(5500.60);
	
		itemsDAO.saveOrUpdate(items);

		
		if (itemsDAO.get("sdfsf") == null) {
			System.out.println("Items does not exist");
		} else {
			System.out.println("Items exist .. the details are ..");
			System.out.println();
		}

	}

}

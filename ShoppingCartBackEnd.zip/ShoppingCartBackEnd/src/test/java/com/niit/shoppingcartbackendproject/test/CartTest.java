package com.niit.shoppingcartbackendproject.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcartbackendproject.dao.CartDAO;
import com.niit.shoppingcartbackendproject.model.Cart;

public class CartTest {
	
	
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.niit.shoppingcartbackendproject");
		context.refresh();
		
		
	   CartDAO cartDAO = 	(CartDAO) context.getBean("cartDAO");
	   
	   Cart cart = 	(Cart) context.getBean("cart");

	   
	   
	   cart.setUserid("Nagashree");
	   cart.setProductName("Laptop");
	   cart.setProductPrice(25000.0);
	   cart.setQuantity("1");
	   cart.setStatus("New");
	   cartDAO.saveOrUpdate(cart);
	   
	 
	  
	 
	}
}


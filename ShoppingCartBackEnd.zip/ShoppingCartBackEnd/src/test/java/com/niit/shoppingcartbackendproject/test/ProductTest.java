package com.niit.shoppingcartbackendproject.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcartbackendproject.dao.ProductDAO;
import com.niit.shoppingcartbackendproject.model.Product;

public class ProductTest {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();

		context.scan("com.niit.shoppingcartbackendproject");
		context.refresh();

		ProductDAO productDAO = (ProductDAO) context.getBean("productDAO");

		Product product = (Product) context.getBean("product");
		product.setId("PRO-1");
		product.setName("Nokia");
		product.setDescription("Communicating India");
		product.setPrice(5500.60);
		;
		productDAO.saveOrUpdate(product);

		product.setId("PRO-2");
		product.setName("Samsung");
		product.setDescription("Connecting People");
		product.setPrice(8500.60);
		;
		productDAO.saveOrUpdate(product);

		product.setId("PRO-3");
		product.setName("Motorola");
		product.setDescription("Life to Enjoy with people");
		product.setPrice(9500.60);
		;
		productDAO.saveOrUpdate(product);

		product.setId("PRO-4");
		product.setName("Lenovo");
		product.setDescription("Chatting World");
		product.setPrice(6500.60);
		;
		productDAO.saveOrUpdate(product);

		product.setId("PRO-5");
		product.setName("Nokia-Lumia");
		product.setDescription("Making World like a class room");
		product.setPrice(4500.60);
		;
		productDAO.saveOrUpdate(product);

		if (productDAO.get("sdfsf") == null) {
			System.out.println("Product does not exist");
		} else {
			System.out.println("Product exist .. the details are ..");
			System.out.println();
		}

	}

}

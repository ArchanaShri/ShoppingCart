package com.niit.shoppingcartbackendproject.dao;

import java.util.List;

import com.niit.shoppingcartbackendproject.model.Items;

public interface ItemsDAO {



	public List<Items> list();

	public Items get(String id);
	
	public void saveOrUpdate(Items items);

	public void delete(String id);



}

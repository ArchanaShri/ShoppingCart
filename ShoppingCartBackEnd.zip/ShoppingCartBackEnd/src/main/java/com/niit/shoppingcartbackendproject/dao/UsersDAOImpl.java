package com.niit.shoppingcartbackendproject.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.shoppingcartbackendproject.model.Users;

@Repository("usersDAO")
public class UsersDAOImpl implements UsersDAO {

	@Autowired
	private SessionFactory sessionFactory;
    @Autowired
	public UsersDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public void saveOrUpdate(Users users) {
		sessionFactory.getCurrentSession().saveOrUpdate(users);

	}

	@Transactional
	public void delete(String id) {
		Users users = new Users();
		users.setId(id);
		sessionFactory.getCurrentSession().delete(users);
	}

	@Transactional
	public Users get(String id) {
		String hql = "from Users where name='" + id + "'";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		List<Users> listUser = (List<Users>) query.list();

		if (listUser != null && !listUser.isEmpty()) {
			return listUser.get(0);
		}
		return null;
	}

	@Transactional
	public List<Users> list() {
		@SuppressWarnings("unchecked")
		List<Users> listUser = (List<Users>) sessionFactory.getCurrentSession().createCriteria(Users.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		return listUser;

	}

	@Transactional
	public boolean isValidUser(String name, String password) {
		System.out.println(name);
		System.out.println(password);
		String hql = "from Users where name='" + name + "' and password='" + password + "'";
		Query q = sessionFactory.getCurrentSession().createQuery(hql);
		List list = q.list();
		if (list == null || list.isEmpty()) {
			return false;
		} else {
			return true;
		}
	}

}

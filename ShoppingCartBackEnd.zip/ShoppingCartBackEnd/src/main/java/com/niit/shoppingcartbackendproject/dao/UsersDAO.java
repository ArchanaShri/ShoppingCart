package com.niit.shoppingcartbackendproject.dao;

import java.util.List;

import com.niit.shoppingcartbackendproject.model.Users;

public interface UsersDAO {



	public List<Users> list();

	public Users get(String id);
	
	public void saveOrUpdate(Users user);

	public void delete(String id);

	public boolean isValidUser(String userID, String password);
}

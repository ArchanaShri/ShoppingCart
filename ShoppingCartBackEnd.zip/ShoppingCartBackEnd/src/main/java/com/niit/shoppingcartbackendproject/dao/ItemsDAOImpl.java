package com.niit.shoppingcartbackendproject.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.shoppingcartbackendproject.model.Items;

@Repository("itemsDAO")
public class ItemsDAOImpl implements ItemsDAO {

	@Autowired
	private SessionFactory sessionFactory;

     @Autowired
	public ItemsDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public void saveOrUpdate(Items items) {
		sessionFactory.getCurrentSession().saveOrUpdate(items);

	}

	@Transactional
	public void delete(String id) {
		Items items = new Items();
		items.setId(id);
		sessionFactory.getCurrentSession().delete(items);
	}

	@Transactional
	public Items get(String id) {
		String hql = "from Items where id=" + "'" + id + "'";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		List<Items> listProduct = (List<Items>) query.list();

		if (listProduct != null && !listProduct.isEmpty()) {
			return listProduct.get(0);
		}
		return null;
	}

	@Transactional
	public List<Items> list() {
		@SuppressWarnings("unchecked")
		List<Items> listItems = (List<Items>) sessionFactory.getCurrentSession().createCriteria(Items.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		return listItems;
	}

}

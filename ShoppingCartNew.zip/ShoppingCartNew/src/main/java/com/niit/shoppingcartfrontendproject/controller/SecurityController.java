package com.niit.shoppingcartfrontendproject.controller;

import java.util.HashSet;
import java.util.Set;

import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.niit.shoppingcartbackendproject.model.Users;

@Controller
public class SecurityController {
	@SuppressWarnings("unchecked")
    @RequestMapping(value="/", method = RequestMethod.GET)
    public String executeSecurityAndLoadHomePage(ModelMap model) {

        String name = null;
        Set<GrantedAuthority> role = new HashSet<GrantedAuthority>();

        //check if user is login
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (!(auth instanceof AnonymousAuthenticationToken)) {
            // Get the user details
            Users users = (Users) auth.getPrincipal();
            name = users.getName();
        }

        // set the model attributes
        model.addAttribute("accountname", name);

        // go to Home page
        return "home";

}
	// Show Login Form
	@RequestMapping(value="/login", method = RequestMethod.GET)
	public String login(ModelMap model, 
	        @RequestParam(value="error",defaultValue="") String error) {

	    // If fails to login
	    if (!error.isEmpty()){
	        model.addAttribute("error", "true");
	    }

	    return "login";

	}
	// Logout page
	@RequestMapping(value="/logout", method = RequestMethod.GET)
	public String logout(ModelMap model) {

	    return "login";

	}
}

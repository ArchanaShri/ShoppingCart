package com.niit.shoppingcartfrontendproject.controller;

import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpSession;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


import com.niit.shoppingcartbackendproject.dao.CategoryDAO;
import com.niit.shoppingcartbackendproject.dao.ProductDAO;
import com.niit.shoppingcartbackendproject.dao.UsersDAO;
import com.niit.shoppingcartbackendproject.model.Category;
import com.niit.shoppingcartbackendproject.model.Product;
import com.niit.shoppingcartbackendproject.model.Users;

@Controller
public class HomeController {
		
	@Autowired
	Users users;

	@Autowired
	private CategoryDAO categoryDAO;
	
	@Autowired
	private UsersDAO usersDAO;

	@Autowired
	private Category category;
	
	@Autowired
	private Product product;
	
	@Autowired
	private ProductDAO productDAO;


	@RequestMapping(value="/")
	public ModelAndView onLoad(HttpServletRequest request,HttpSession session) {
		ModelAndView mv = new ModelAndView("/home");
		mv.addObject("category", category);
		mv.addObject("categoryList", categoryDAO.list());
		return mv;
	}

	@RequestMapping("/registerHere")
	public ModelAndView registerHere() {
		ModelAndView mv = new ModelAndView("/home");
		mv.addObject("users", users);
		mv.addObject("isUserClickedRegisterHere", "true");
		return mv;
	}

	@RequestMapping("/loginHere")
	public ModelAndView loginHere() {
		ModelAndView mv = new ModelAndView("/home");
		mv.addObject("users", users);
		mv.addObject("isUserClickedLoginHere", "true");
		return mv;
	}
	@RequestMapping(value = "user/register", method = RequestMethod.POST)
	public ModelAndView registration(@ModelAttribute Users users) {
		usersDAO.saveOrUpdate(users);
		ModelAndView mv = new ModelAndView("/home");
		mv.addObject("successMessage", "Successfully Registered");
		return mv;
	}


	
}

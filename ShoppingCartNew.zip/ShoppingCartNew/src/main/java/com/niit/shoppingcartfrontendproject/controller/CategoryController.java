package com.niit.shoppingcartfrontendproject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.shoppingcartbackendproject.dao.CategoryDAO;
import com.niit.shoppingcartbackendproject.model.Category;

@Controller
public class CategoryController {
	@Autowired
	private CategoryDAO categoryDAO;
	@Autowired
	private Category category;

	@RequestMapping(value = "/category", method = RequestMethod.GET)
	public String categoryList(Model model) {
		model.addAttribute("category", category);
		model.addAttribute("categoryList", this.categoryDAO.list());
		return "redirect:/manageCategories";
	}

	@RequestMapping(value = "/category/add", method = RequestMethod.POST)
	public String categoryAdd(@ModelAttribute("category") Category category) {
		System.out.println(category);
		categoryDAO.saveOrUpdate(category);
		return "redirect:/manageCategories";
	}

	@RequestMapping("/category/remove/{id}")
	public String categoryRemove(@PathVariable("id") String id) throws Exception {
		categoryDAO.delete(id);
		return "redirect:/manageCategories";
	}

	@RequestMapping("/category/edit/{id}")
	public String categoryRemove(@PathVariable("id") String id, ModelMap model) throws Exception {
		category = categoryDAO.get(id);
		model.addAttribute("category", category);
		model.addAttribute("categoryList", this.categoryDAO.list());
		return "category";
	}

}

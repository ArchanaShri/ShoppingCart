package com.niit.shoppingcartfrontendproject.controller;

import javax.servlet.http.HttpSession;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.shoppingcartbackendproject.dao.CartDAO;
import com.niit.shoppingcartbackendproject.dao.ItemsDAO;
import com.niit.shoppingcartbackendproject.dao.ProductDAO;
import com.niit.shoppingcartbackendproject.dao.UsersDAO;
import com.niit.shoppingcartbackendproject.model.Cart;
import com.niit.shoppingcartbackendproject.model.Items;
import com.niit.shoppingcartbackendproject.model.Product;
import com.niit.shoppingcartbackendproject.model.Users;

@Controller
public class CartController {
    
	@Autowired
	private ProductDAO productDAO;
    @Autowired
	private CartDAO cartDAO;
	@Autowired
	private Cart cart;
	@Autowired
	private Items items;
	@Autowired
	private ItemsDAO itemsDAO;
	@Autowired
	private UsersDAO usersDAO;

	@RequestMapping(value = "/myCartDisplay", method = RequestMethod.GET)
	public String cart(Model model, HttpSession session) {
		model.addAttribute("cart", cart);
		String loggedInUserid = (String) session.getAttribute("loggedInUserID");
		String loggedInUser=(String) session.getAttribute("loggedInUser");
		model.addAttribute("cart", cartDAO.get(loggedInUserid));
		model.addAttribute("cartList", cartDAO.list(loggedInUser));
		model.addAttribute("totalAmount", cartDAO.totalAmount(loggedInUser));
		model.addAttribute("isAdmin", false);
		model.addAttribute("cartSize", cartDAO.list(loggedInUser).size());
		model.addAttribute("displayCart", "true");
		return "/home";
	}

	@RequestMapping(value="/cart/add/{id}",method=RequestMethod.GET)
	public String addToCart(@PathVariable("id") String id, HttpSession session,Model model) {
		System.out.println(id);
		Items items = itemsDAO.get(id);
		System.out.println(items.getId());
		System.out.println(items.getName());
		System.out.println(items.getPrice());
		cart.setProductPrice(items.getPrice());
		cart.setProductName(items.getName());
		cart.setQuantity("1");
		String loggedInUserid = (String) session.getAttribute("loggedInUserID");
		String loggedInUser=(String) session.getAttribute("loggedInUser");
		System.out.println(loggedInUserid);
		System.out.println(loggedInUser);
		cart.setUserid(loggedInUser);
		cart.setStatus("New");
		cartDAO.saveOrUpdate(cart);
		model.addAttribute("isAdmin", false);
		model.addAttribute("cartSize", cartDAO.list(loggedInUserid).size());
		return "/home";
	}


	@RequestMapping("cart/delete/{id}")

	public String removeCart(@PathVariable("id") String id, ModelMap model) throws Exception 
	{
		try 
		{
			cartDAO.delete(id);
			model.addAttribute("message", "Successfully Removed");
			
		} 
		catch (Exception e) 
		{
			model.addAttribute("message", e.getMessage());
			e.printStackTrace();
		}
		return "redirect:/myCartDisplay";
	}
	
	@RequestMapping("cart/edit/{id}")
	public String editCart(@PathVariable("id") String id, Model model, HttpSession session)
	{
		model.addAttribute("cart", this.cartDAO.get(id));
		model.addAttribute("listCarts", this.cartDAO.list(id));
		return "cart";
	}
}

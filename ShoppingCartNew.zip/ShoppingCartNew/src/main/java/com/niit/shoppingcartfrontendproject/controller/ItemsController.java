package com.niit.shoppingcartfrontendproject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.shoppingcartbackendproject.dao.ItemsDAO;
import com.niit.shoppingcartbackendproject.model.Items;

@Controller
public class ItemsController {
	@Autowired
	private ItemsDAO itemsDAO;
	@Autowired
	private Items items;

	@RequestMapping(value = "/items", method = RequestMethod.GET)
	public String itemsList(Model model) {
		model.addAttribute("items", items);
		model.addAttribute("itemsList", this.itemsDAO.list());
		return "redirect:/manageItems";
	}

	@RequestMapping(value = "/items/add", method = RequestMethod.POST)
	public String itemsAdd(@ModelAttribute("items") Items items) {
		System.out.println(items);
		itemsDAO.saveOrUpdate(items);
		return "redirect:/manageItems";
	}

	@RequestMapping("/items/remove/{id}")
	public String itemsRemove(@PathVariable("id") String id) throws Exception {
		itemsDAO.delete(id);
		return "redirect:/manageItems";
	}

	@RequestMapping("/items/edit/{id}")
	public String itemsRemove(@PathVariable("id") String id, ModelMap model) throws Exception {
		items = itemsDAO.get(id);
		model.addAttribute("items", items);
		model.addAttribute("itemsList", this.itemsDAO.list());
		return "items";
	}

}

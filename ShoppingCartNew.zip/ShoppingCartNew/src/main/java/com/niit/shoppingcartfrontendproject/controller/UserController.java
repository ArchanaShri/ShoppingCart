package com.niit.shoppingcartfrontendproject.controller;

import java.util.List;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcartbackendproject.dao.CartDAO;
//import com.niit.shoppingcartbackendproject.dao.CartDAO;
import com.niit.shoppingcartbackendproject.dao.CategoryDAO;
import com.niit.shoppingcartbackendproject.dao.UsersDAO;
import com.niit.shoppingcartbackendproject.model.Cart;
//import com.niit.shoppingcartbackendproject.model.Cart;
import com.niit.shoppingcartbackendproject.model.Category;
import com.niit.shoppingcartbackendproject.model.Users;

@Controller
public class UserController {

	@Autowired
	UsersDAO usersDAO;

	@Autowired
	Users users;

	@Autowired
	private CategoryDAO categoryDAO;

	@Autowired
	private Category category;
	
	@Autowired
	private Cart cart;
	
	@Autowired
	private CartDAO cartDAO;
	
	

	/**
	 * if invalid credentials -> Home page , login , error message if valid
	 * credentials && he is admin -> AdminHome page ,logout link if valid
	 * credentials && he is end user -> Home page, cart, logout link
	 * 
	 * @param userID
	 * @param password
	 * @return it will return data and page name where to return
	 */
	@RequestMapping("/login")
	public ModelAndView login(@RequestParam(value = "name") String name,
			@RequestParam(value = "password") String password, HttpSession session) {

		ModelAndView mv = new ModelAndView("home");
		boolean isValidUser = usersDAO.isValidUser(name, password);

		if (isValidUser == true)
		{
			users = usersDAO.get(name);
			System.out.println(users);
			session.setAttribute("loggedInUser",users.getName());
			session.setAttribute("loggedInUserID", users.getId());
			if (users.getAdmin() == true)
			{
				mv.addObject("isAdmin", "true");

			} 
			else 
			{
				mv.addObject("isAdmin", "false");
				cart=cartDAO.get(name);     
				mv.addObject("cart", cart);
				List<Cart> cartList = cartDAO.list(name);
				System.out.println(cartList.size());
				mv.addObject("cartList", cartList);
				mv.addObject("cartSize", cartList.size());
			}

		} 
		else 
		{

			mv.addObject("inValidCredentials", "true");
			mv.addObject("errorMessage", "Invalid Credentials");
			mv.addObject("msg","Please Enter Valid USERNAME and PASSWORD");

		}
		return mv;
	}

	@RequestMapping("/logout")
	public ModelAndView logout(HttpServletRequest request, HttpSession session) {
		ModelAndView mv = new ModelAndView("/home");
		session.invalidate();
		session = request.getSession(true);
		session.setAttribute("category", category);
		session.setAttribute("categoryList", categoryDAO.list());
		mv.addObject("logoutMessage", "You have successfully logged out");
		mv.addObject("loggedOut", "true");

		return mv;
	}
}

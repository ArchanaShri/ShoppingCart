package com.niit.shoppingcartfrontendproject.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.niit.shoppingcartbackendproject.dao.CartDAO;
import com.niit.shoppingcartbackendproject.dao.CategoryDAO;
import com.niit.shoppingcartbackendproject.dao.ItemsDAO;
import com.niit.shoppingcartbackendproject.dao.ProductDAO;
import com.niit.shoppingcartbackendproject.dao.SupplierDAO;
import com.niit.shoppingcartbackendproject.model.Category;
import com.niit.shoppingcartbackendproject.model.Items;
import com.niit.shoppingcartbackendproject.model.Product;
import com.niit.shoppingcartbackendproject.model.Supplier;

@Controller
public class ProductController {
	@Autowired(required=true)
	private ProductDAO productDAO;
	@Autowired(required=true)
	private Product product;
	@Autowired(required=true)
	private SupplierDAO supplierDAO;
	@Autowired(required=true)
	private Supplier supplier;
	@Autowired(required=true)
	private CategoryDAO categoryDAO;
	@Autowired(required=true)
	private Category category;
	@Autowired(required=true)
	private Items items;
	@Autowired(required=true)
	private ItemsDAO itemsDAO;
	@Autowired
	private CartDAO cartDAO;
	
	

	@RequestMapping(value = "/product", method = RequestMethod.GET)
	public String productList(Model model) {
		model.addAttribute("product", product);
		model.addAttribute("category", category);
		model.addAttribute("supplier", supplier);
		model.addAttribute("productList", this.productDAO.list());
		model.addAttribute("categoryList", this.categoryDAO.list());
		model.addAttribute("supplierList", this.supplierDAO.list());
		return "redirect:/manageProducts";
	}

	@RequestMapping(value = "/product/add", method = RequestMethod.POST)
	public String productAdd(@ModelAttribute("product") Product product) {
		//Category category = categoryDAO.get(product.getCategory().getId());
		//categoryDAO.saveOrUpdate(category);
		
		//Supplier supplier =supplierDAO.get(product.getSupplier().getId());
		//supplierDAO.saveOrUpdate(supplier);
		
		//product.setCategory(category);
		//product.setSupplier(supplier);
		
		//product.setCategory_id(category.getId());
		//product.setSupplier_id(supplier.getId());
		productDAO.saveOrUpdate(product);
		return "redirect:/manageProducts";
	}

	@RequestMapping("/product/remove/{id}")
	public String productRemove(@PathVariable("id") String id) throws Exception {
		productDAO.delete(id);
		return "redirect:/manageProducts";
	}

	@RequestMapping("/product/edit/{id}")
	public String productEdit(@PathVariable("id") String id, Model model) {
		product = productDAO.get(id);
		model.addAttribute("product", product);
		model.addAttribute("productList", this.productDAO.list());
		model.addAttribute("categoryList", this.categoryDAO.list());
		model.addAttribute("supplierList", this.supplierDAO.list());
		//product.setCategory_id("Cat-1");
		//product.setSupplier_id("Sup-1");
		return "product";
	}
	
	@RequestMapping(value="/product/get/{id}")
	public String getProduct(@PathVariable("id") String id, Model model, HttpSession session,RedirectAttributes redirectAttributes){
		//redirectAttributes.addFlashAttribute("selectedProduct",productDAO.get(id));
		System.out.println(id);
		product=productDAO.get(id);
		items=itemsDAO.get(product.getId());
		/*model.addAttribute("product", product);
		model.addAttribute("productList", this.productDAO.list());*/
		System.out.println(productDAO.get(id));
		model.addAttribute("product", product);
		model.addAttribute("productList", this.productDAO.list());
		model.addAttribute("items", items);
		model.addAttribute("itemsList", this.itemsDAO.list());
		model.addAttribute("isAdmin", false);
		model.addAttribute("cartSize", cartDAO.list().size());
		model.addAttribute("selectedItems", true);
		return "/home";
	}

}

package com.niit.shoppingcartbackendproject.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.shoppingcartbackendproject.model.Cart;
import com.niit.shoppingcartbackendproject.model.Category;

@Repository("cartDAO")
public class CartDAOImpl implements CartDAO {
	int c=1;
	@Autowired
	private SessionFactory sessionFactory;

    @Autowired
	public CartDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public void saveOrUpdate(Cart cart) {
		
		System.out.println(++c);
		sessionFactory.getCurrentSession().save(cart);

	}

	@Transactional
	public String delete(String id) {
		Cart cart = new Cart();
		cart.setId(id);
		try {
			sessionFactory.getCurrentSession().delete(cart);
		} catch (HibernateException e) {
			e.printStackTrace();
			return e.getMessage();
		}
		return null;
	}

	@Transactional
	public List<Cart> list(String id) {
		String hql="from Cart where userid='"+id+"'";
		Query query=sessionFactory.getCurrentSession().createQuery(hql);
		List<Cart> list =(List<Cart>) query.list();
		return list;
		
	}

	@Transactional
	public Double totalAmount(String id) {
		System.out.println(id);
		String hql = "select sum(productPrice) from Cart where userid='" + id + "'";
		Query q = sessionFactory.getCurrentSession().createQuery(hql);
		System.out.println(q);
		Double sum = (Double) q.uniqueResult();
		System.out.println(sum);
		return sum;
	}
	@Transactional
	public Cart get(String id) {
		String hql = "from Cart where userid=" + "'"+ id +"'";
		Query query =  sessionFactory.getCurrentSession().createQuery(hql);
		List<Cart> listCategory = (List<Cart>) query.list();
		
		if (listCategory != null && !listCategory.isEmpty()) {
			return listCategory.get(0);
		}
		return null;	}

}
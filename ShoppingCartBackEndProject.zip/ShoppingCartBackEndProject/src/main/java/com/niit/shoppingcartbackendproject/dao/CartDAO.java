package com.niit.shoppingcartbackendproject.dao;

import java.util.List;

import com.niit.shoppingcartbackendproject.model.Cart;

public interface CartDAO {
	public List<Cart> list(String id);
	public void saveOrUpdate(Cart cart);
	public String delete(String id);
	public Double totalAmount(String id);
	public Cart get(String id);
}
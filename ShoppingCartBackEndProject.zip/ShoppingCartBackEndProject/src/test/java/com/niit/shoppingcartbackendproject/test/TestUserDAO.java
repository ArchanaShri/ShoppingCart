package com.niit.shoppingcartbackendproject.test;
/*package com.niit.shoppingcartbackendproject.test;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcartbackendproject.dao.UsersDAO;
import com.niit.shoppingcartbackendproject.model.Users;

public class TestUserDAO {

	static UsersDAO usersDAO;
	static Users users;
	static AnnotationConfigApplicationContext context;
	@BeforeClass
	public static void init()
	{
		context=new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		usersDAO=(UsersDAO) context.getBean("usersDAO");
		users=(Users) context.getBean("users");
	}

	@AfterClass
	public static void close()
	{
		context.close();
		usersDAO=null;
		users=null;
	}
	@Test
	public void usersTestCase() {
     int size=usersDAO.list().size();
     assertEquals("Users list test case",6,size);
	
	}
	@Test
	public void userNameTestCase()
	{
		users=usersDAO.get("users-2");
		String name=users.getName();
		assertEquals("Name Test Case","Nagashree", name);
	}


}*/

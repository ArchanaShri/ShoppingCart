package com.niit.shoppingcartbackendproject.test;
/*package com.niit.shoppingcartbackendproject.test;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcartbackendproject.dao.CategoryDAO;
import com.niit.shoppingcartbackendproject.model.Category;

public class TestCategoryDAO {
	
	static CategoryDAO categoryDAO;
	static Category category;
	static AnnotationConfigApplicationContext context;
	@BeforeClass
	public static void init()
	{
		context=new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		categoryDAO=(CategoryDAO) context.getBean("categoryDAO");
		category=(Category) context.getBean("category");
	}

	@AfterClass
	public static void close()
	{
		context.close();
		categoryDAO=null;
		category=null;
	}
	@Test
	public void categoryTestCase() {
     int size=categoryDAO.list().size();
     assertEquals("Category list test case",6,size);
	
	}
	@Test
	public void userNameTestCase()
	{
		category=categoryDAO.get("CG121");
		String name=category.getName();
		assertEquals("Name Teest Case","CGName124", name);
	}

}*/
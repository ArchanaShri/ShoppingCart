package com.niit.shoppingcartbackendproject.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;


import com.niit.shoppingcartbackendproject.dao.CategoryDAO;
import com.niit.shoppingcartbackendproject.model.Category;

public class CategoryTest {
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
	
		context.scan("com.niit.shoppingcartbackendproject");
		context.refresh();
		
	
	   CategoryDAO categoryDAO = 	(CategoryDAO) context.getBean("categoryDAO");
	   
	   Category category = 	(Category) context.getBean("category");
	   
	   
	   
	   category.setId("CG126");
	   category.setName("souvik");
	   category.setDescription("CGDesc124");
	   categoryDAO.saveOrUpdate(category);
	   
	   category = categoryDAO.get("CG126");
	   System.out.println(category.getName());
	   
	   
	   
	  if(   categoryDAO.get("CG120")  == null )
	  {
		  System.out.println("Category does not exist");
	  }
	  else
	  {
		  System.out.println("Category exist .. the details are ..");
		  System.out.println();
	  }
		
		
		
	}

}

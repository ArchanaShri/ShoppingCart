package com.niit.shoppingcartbackendproject.test;
/*package com.niit.shoppingcartbackendproject.test;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcartbackendproject.dao.ProductDAO;
import com.niit.shoppingcartbackendproject.model.Product;

public class TestProductDAO {
	
	static ProductDAO productDAO;
	static Product product;
	static AnnotationConfigApplicationContext context;
	@BeforeClass
	public static void init()
	{
		context=new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		productDAO=(ProductDAO) context.getBean("productDAO");
		product=(Product) context.getBean("product");
	}

	@AfterClass
	public static void close()
	{
		context.close();
		productDAO=null;
		product=null;
	}
	@Test
	public void productTestCase() {
     int size=productDAO.list().size();
     assertEquals("Product list test case",8,size);
	
	}
	@Test
	public void userNameTestCase()
	{
		product=productDAO.get("PRO-1");
		String name=product.getName();
		assertEquals("Name Teest Case","Nokia", name);
	}

}*/

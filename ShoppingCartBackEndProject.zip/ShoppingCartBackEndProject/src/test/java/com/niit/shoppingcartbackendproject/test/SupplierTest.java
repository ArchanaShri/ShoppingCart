package com.niit.shoppingcartbackendproject.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcartbackendproject.dao.SupplierDAO;
import com.niit.shoppingcartbackendproject.model.Supplier;

public class SupplierTest {
	
	
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.niit.shoppingcartbackendproject");
		context.refresh();
		
		
	   SupplierDAO supplierDAO = 	(SupplierDAO) context.getBean("supplierDAO");
	   
	   Supplier supplier = 	(Supplier) context.getBean("supplier");
	   supplier.setId("Sup-1");
	   supplier.setName("Raj");
	   supplier.setAddress("RAJAJINAGAR");  
	   supplierDAO.saveOrUpdate(supplier);
	   
	   supplier.setId("Sup-2");
	   supplier.setName("Vijay");
	   supplier.setAddress("T-nagar");  
	   supplierDAO.saveOrUpdate(supplier);
	   
	   supplier.setId("Sup-3");
	   supplier.setName("Ravi");
	   supplier.setAddress("S-nagar");  
	   supplierDAO.saveOrUpdate(supplier);
	   
	   supplier.setId("Sup-4");
	   supplier.setName("Priya");
	   supplier.setAddress("V-nagar");  
	   supplierDAO.saveOrUpdate(supplier);
	   
	   supplier.setId("Sup-5");
	   supplier.setName("Hema");
	   supplier.setAddress("M-nagar");  
	   supplierDAO.saveOrUpdate(supplier);
	   
	   
	   
	  if(   supplierDAO.get("Sup-1") ==null)
	  {
		  System.out.println("Supplier does not exist");
	  }
	  else
	  {
		  System.out.println("Supplier exist .. the details are ..");
		  System.out.println();
	  }
		
		
		
	}

}
